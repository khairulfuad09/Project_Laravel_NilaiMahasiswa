</main>
</div>
</div>
<?php /**PATH D:\Aplications_Laravel\ProjectHasnur\resources\views/partials/footer.blade.php ENDPATH**/ ?>