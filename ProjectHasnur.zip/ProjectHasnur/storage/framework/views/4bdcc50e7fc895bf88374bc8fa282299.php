
<?php $__env->startSection('container'); ?>
    
    
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Data Nilai Mahasiswa</h1>
    </div>

    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
        Tambah Data Nilai
    </button>


    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Program Studi</th>
                <th scope="col">Mata kuliah</th>
                <th scope="col">Nilai tugas</th>
                <th scope="col">Nilai uts</th>
                <th scope="col">Nilai uas</th>
                <th scope="col">Grade</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($nl->nim); ?></td>
                    <td><?php echo e($nl->nama); ?></td>
                    <td><?php echo e($nl->program_studi); ?></td>
                    <td><?php echo e($nl->mata_kuliah); ?></td>
                    <td><?php echo e($nl->tugas); ?></td>
                    <td><?php echo e($nl->uts); ?></td>
                    <td><?php echo e($nl->uas); ?></td>
                    <td><?php echo e($nl->grade); ?></td>
                    <td>
                        
                        <a class="btn btn-primary" href="/nilai/<?php echo e($nl->id); ?>/edit">Edit</a>
                        <form action="/nilai/<?php echo e($nl->id); ?>" method="post">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger"
                                onclick="return confirm('Anda yakin ingin menghapus data ini?')">hapus</button>
                        </form>
                    </td>
                </tr>

                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($nilai->links()); ?>

<?php $__env->stopSection(); ?>

<!-- Modal -->
<form action="/nilai" method="post">
    <?php echo csrf_field(); ?>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data Nilai Mahasiswa</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nim</label>
                        <input type="text" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" name="nim" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Mata Kuliah</label>
                        <input type="text" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" name="mata_kuliah" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nilai Tugas</label>
                        <input type="number" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" name="tugas" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nilai Uts</label>
                        <input type="number" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" name="uts" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nilai Uas</label>
                        <input type="number" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" name="uas" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </div>
    </div>
</form>

<?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplications_Laravel\ProjectHasnur\resources\views/nilai.blade.php ENDPATH**/ ?>