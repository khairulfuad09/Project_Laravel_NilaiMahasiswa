
<?php $__env->startSection('container'); ?>
    <!-- Modal -->
    <form action="/nilai/<?php echo e($nl->id); ?>" method="post">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nim</label>
                                <input type="text" class="form-control" id="exampleInputEmail1"
                                    aria-describedby="emailHelp" name="nim" value="<?php echo e($nl->nim); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Mata Kuliah</label>
                                <input type="text" class="form-control" id="exampleInputEmail1"
                                    aria-describedby="emailHelp" name="mata_kuliah" value="<?php echo e($nl->mata_kuliah); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nilai Tugas</label>
                                <input type="number" class="form-control" id="exampleInputEmail1"
                                    aria-describedby="emailHelp" name="tugas" value="<?php echo e($nl->tugas); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nilai Uts</label>
                                <input type="number" class="form-control" id="exampleInputEmail1"
                                    aria-describedby="emailHelp" name="uts" value="<?php echo e($nl->uts); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nilai Uas</label>
                                <input type="number" class="form-control" id="exampleInputEmail1"
                                    aria-describedby="emailHelp" name="uas" value="<?php echo e($nl->uas); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
                        <button type="submit" class="btn btn-primary">Perbarui</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplications_Laravel\ProjectHasnur\resources\views/editnilai.blade.php ENDPATH**/ ?>